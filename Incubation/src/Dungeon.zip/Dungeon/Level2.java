package Dungeon;

public class Level2 extends Level11 {

}
