package Dungeon;

public class Level6 {

}
