package Dungeon;
import java.util.Scanner;

//import Dungeon.Level1;
public class Main   {

	
		
		public static void main(String[] args) { 		
//		   	int[][] matrix = {
//			   {1, 1, 1},
//			   {01, 01, 01},
//			   {01, 01, 1}};
		   	
		   	int[] Astart = new int[2];
		   	int[] end = new int[2];
		   	int[] Mstart = new int[2];
		   	int[] Trigger = new int[2];
		   	Scanner sc = new Scanner(System.in);
		   	System.out.println("Dimensions of the dungeon(Row  Column):");// 5 4
		   	int row = sc.nextInt();
		   	int col = sc.nextInt();
		   	int mat[][] = new int[row][col];
		   	System.out.println("Position of Adventurer:");// 4 1
		   	Astart[0]=sc.nextInt()-1;
		   	Astart[1]=sc.nextInt()-1;
		   	System.out.println("Position of Gold:");// 3 1
		   	end[0]=sc.nextInt()-1;
		   	end[1]=sc.nextInt()-1;
		   	System.out.println("Position of monster:");
		   	Mstart[0]=sc.nextInt()-1;
		   	Mstart[1]=sc.nextInt()-1;
		   	System.out.println("Position of trigger:");
		   	Trigger[0]=sc.nextInt()-1;
		   	Trigger[1]=sc.nextInt()-1;
		   	for(int i=0;i<row;i++) {
		   		for(int j=0;j<col;j++)
		   		{
		   			mat[i][j]=1;
		   		}
		   	}
		   	
		   	int Asteps=Level1.shortestPath(mat, Astart, end);
		   	int Msteps =Level1.shortestPath(mat, Mstart, end);
		   	int AtoTsteps = Level1.shortestPath(mat, Astart, Trigger);
		 
		   if(Asteps<=Msteps)
		   {
			   System.out.println("Minimum number of Steps : "+Asteps);
			   
		   }
		   else
		   {
			   
		   }
//			   if(){
//			   System.out.println("No Possible Solution");
//		   }
//		   else
//		   {
//			   System.out.println("Minimum number of Steps : "+Msteps);
//		   }
		   
		   	
		} 
	}
	
