package Dungeon;

import java.util.LinkedList;
import java.util.Scanner;

public class Level11 {
	Scanner sc = new Scanner(System.in);
    int row,column,adventureX,adventureY,goldX,goldY;
    int matrix[][];
    public void setL1(int row, int column, int adventureX, int adventureY, int goldX, int goldY)
    {
    	this.row=row;
    	this.column=column;
    	this.adventureX=adventureX;
    	this.adventureY=adventureY;
    	this.goldX=goldX;
    	this.goldY=goldY;
    	matrix=new int[row][column];
		for(int i=0;i<row;i++) {
	   		for(int j=0;j<column;j++)
	   		{
	   			matrix[i][j]=1;
	   		}
	   	}
    }
	public LinkedList<Start.Cell> find()
	{
		return Start.shortestPath(matrix,adventureX,adventureY,goldX,goldY);
    }
}
